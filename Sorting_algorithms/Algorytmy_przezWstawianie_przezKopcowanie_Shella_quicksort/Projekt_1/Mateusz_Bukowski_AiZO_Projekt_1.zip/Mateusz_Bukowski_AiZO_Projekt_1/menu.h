#include <iostream>

using namespace std;

void menu();								// funkcja wy�wietlaj�ac menu an ekranie
void choice_switch();						// funkcja odpowiedzialna za dalsze dzia�ania programu w zale�no�ci od wyboru jaki zrobi� u�ytkownik na podstawie wy�wietlanego menu
void generation_int(int, char);				// funkcja odpowiedzialna za generowanie r�nych rodzaj�w tablic poczatkowych z elementami b�d�cymi liczbami ca�kowitymi
void generation_float(int, char);			// funkcja odpowiedzialna za generowanie r�nych rodzaj�w tablic poczatkowych z elementami b�d�cymi liczbami rzeczywistymi


